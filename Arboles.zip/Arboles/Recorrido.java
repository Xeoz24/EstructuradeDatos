package Arboles;

public enum Recorrido {
  PREFIJO, INFIJO, POSFIJO;
}
